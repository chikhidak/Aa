package com.aroma.ledger

import android.app.*
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.*
import android.widget.*
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max

private data class Product(
    val id: Long,
    var name: String,
    var stock: Int,
    var buyPrice: Long,
    var sellPrice: Long
)

private data class InvoiceLine(
    var productId: Long,
    var productName: String,
    var qty: Int,
    var unitPrice: Long
) {
    val total: Long get() = qty * unitPrice
}

private class Store(private val context: Context) {
    private val dir = File(context.filesDir, "data").apply { mkdirs() }
    private val productsFile = File(dir, "products.csv")
    private val purchasesFile = File(dir, "purchases.csv")
    private val salesFile = File(dir, "sales.csv")

    init {
        if (!productsFile.exists()) productsFile.writeText("id,name,stock,buy_price,sell_price\n")
        if (!purchasesFile.exists()) purchasesFile.writeText("invoice_id,name,phone,date,product_id,product,qty,unit_price,total\n")
        if (!salesFile.exists()) salesFile.writeText("invoice_id,name,phone,date,product_id,product,qty,unit_price,total\n")
    }

    fun products(): MutableList<Product> {
        if (!productsFile.exists()) return mutableListOf()
        return productsFile.readLines().drop(1).filter { it.isNotBlank() }.mapNotNull { row ->
            val c = parseCsv(row)
            if (c.size >= 5) Product(c[0].toLongOrNull() ?: 0L, c[1], c[2].toIntOrNull() ?: 0, c[3].toLongOrNull() ?: 0, c[4].toLongOrNull() ?: 0) else null
        }.toMutableList()
    }

    fun saveProducts(list: List<Product>) {
        productsFile.writeText("id,name,stock,buy_price,sell_price\n")
        list.forEach { p -> productsFile.appendText(csv(p.id, p.name, p.stock, p.buyPrice, p.sellPrice) + "\n") }
    }

    fun addInvoice(isSale: Boolean, name: String, phone: String, date: String, invoiceId: Long, lines: List<InvoiceLine>) {
        val file = if (isSale) salesFile else purchasesFile
        lines.forEach { l ->
            file.appendText(csv(invoiceId, name, phone, date, l.productId, l.productName, l.qty, l.unitPrice, l.total) + "\n")
        }
    }

    fun exportCsv(): List<File> = listOf(productsFile, purchasesFile, salesFile)

    fun nextInvoiceId(): Long = System.currentTimeMillis()

    private fun csv(vararg values: Any?): String = values.joinToString(",") { escapeCsv(it?.toString() ?: "") }
    private fun escapeCsv(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
    private fun parseCsv(line: String): List<String> {
        val out = mutableListOf<String>(); val sb = StringBuilder(); var quoted = false; var i = 0
        while (i < line.length) {
            val ch = line[i]
            if (ch == '"') {
                if (quoted && i + 1 < line.length && line[i + 1] == '"') { sb.append('"'); i++ } else quoted = !quoted
            } else if (ch == ',' && !quoted) { out.add(sb.toString()); sb.setLength(0) } else sb.append(ch)
            i++
        }
        out.add(sb.toString()); return out
    }
}

class MainActivity : Activity() {
    private lateinit var store: Store
    private lateinit var root: LinearLayout
    private val bg = Color.rgb(13, 14, 15)
    private val panel = Color.rgb(21, 23, 25)
    private val cream = Color.rgb(233, 215, 193)
    private val white = Color.rgb(245, 243, 239)
    private val muted = Color.rgb(142, 138, 132)
    private val danger = Color.rgb(201, 124, 124)
    private val dp get() = resources.displayMetrics.density

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = bg
        store = Store(this)
        showDashboard()
    }

    private fun base(title: String): LinearLayout {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); layoutDirection = View.LAYOUT_DIRECTION_RTL; textDirection = View.TEXT_DIRECTION_RTL }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18), dp(12), dp(18), dp(8)) }
        val back = TextView(this).apply { text = "‹"; textSize = 34f; setTextColor(cream); gravity = Gravity.CENTER; visibility = if (title == "Aroma حساب") View.GONE else View.VISIBLE; setOnClickListener { showDashboard() } }
        top.addView(back, LinearLayout.LayoutParams(dp(44), dp(54)))
        val t = TextView(this).apply { text = title; textSize = 22f; typeface = android.graphics.Typeface.DEFAULT_BOLD; setTextColor(white); gravity = Gravity.CENTER_VERTICAL }
        top.addView(t, LinearLayout.LayoutParams(0, dp(54), 1f))
        val logo = ImageView(this).apply { setImageResource(com.aroma.ledger.R.drawable.app_icon); scaleType = ImageView.ScaleType.CENTER_CROP; clipToOutline = true }
        top.addView(logo, LinearLayout.LayoutParams(dp(54), dp(54)))
        root.addView(top)
        return root
    }

    private fun scroll(content: View): View = ScrollView(this).apply { setFillViewport(true); addView(content) }
    private fun dp(v: Int) = (v * dp).toInt()

    private fun text(s: String, size: Float = 15f, color: Int = white, bold: Boolean = false): TextView = TextView(this).apply { text = s; textSize = size; setTextColor(color); if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD; setPadding(dp(2), dp(2), dp(2), dp(2)) }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14)); background = android.graphics.drawable.GradientDrawable().apply { setColor(panel); cornerRadius = dp(20).toFloat() }; elevation = dp(5).toFloat()
    }

    private fun button(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label; textSize = 15f; setTextColor(cream); gravity = Gravity.CENTER; typeface = android.graphics.Typeface.DEFAULT_BOLD
        setPadding(dp(12), dp(13), dp(12), dp(13)); background = android.graphics.drawable.GradientDrawable().apply { setColor(Color.rgb(28,30,32)); cornerRadius = dp(16).toFloat(); setStroke(dp(1), Color.rgb(50,48,46)) }; elevation = dp(3).toFloat(); setOnClickListener { onClick() }
    }

    private fun showDashboard() {
        val v = base("Aroma حساب")
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), dp(24)) }
        val products = store.products()
        val stock = products.sumOf { it.stock }
        content.addView(text("حسابداری ساده فروش عطر", 14f, muted), LinearLayout.LayoutParams(-1, dp(30)))
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        statCard(stats, "موجودی انبار", stock.toString(), "عدد")
        statCard(stats, "تعداد کالا", products.size.toString(), "قلم")
        content.addView(stats, LinearLayout.LayoutParams(-1, dp(112)))
        space(content, 12)
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        rowButtons(grid, listOf("فاکتور فروش" to { showInvoice(true) }, "فاکتور خرید" to { showInvoice(false) }))
        rowButtons(grid, listOf("انبار" to { showInventory() }, "خروجی CSV" to { exportCsv() }))
        content.addView(grid)
        space(content, 18)
        val note = card(); note.addView(text("اطلاعات داخل فایل‌های CSV ذخیره می‌شوند و هر زمان بخواهی می‌توانی از بخش «خروجی CSV» آن‌ها را به پوشه Download منتقل کنی.", 13f, muted)); content.addView(note)
        v.addView(scroll(content), LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(v)
    }

    private fun statCard(parent: LinearLayout, title: String, value: String, suffix: String) {
        val c = card(); c.addView(text(title, 12f, muted)); val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(text(value, 27f, white, true), LinearLayout.LayoutParams(0, dp(45), 1f)); row.addView(text(suffix, 12f, cream)); c.addView(row)
        parent.addView(c, LinearLayout.LayoutParams(0, dp(96), 1f).apply { marginStart = dp(5); marginEnd = dp(5) })
    }

    private fun rowButtons(parent: LinearLayout, items: List<Pair<String, () -> Unit>>) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        items.forEach { (label, action) -> row.addView(button(label, action), LinearLayout.LayoutParams(0, dp(76), 1f).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) }) }
        parent.addView(row)
    }

    private fun space(parent: LinearLayout, h: Int) { parent.addView(Space(this), LinearLayout.LayoutParams(1, dp(h))) }

    private fun showInventory() {
        val v = base("انبار")
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), 0, dp(18), dp(24)) }
        content.addView(button("＋ افزودن عطر", { productDialog(null) }), LinearLayout.LayoutParams(-1, dp(58)).apply { bottomMargin = dp(12) })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        store.products().forEach { p ->
            val c = card(); val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            top.addView(text(p.name, 17f, white, true), LinearLayout.LayoutParams(0, dp(40), 1f)); top.addView(text("موجودی ${p.stock}", 13f, if (p.stock <= 2) danger else cream)); c.addView(top)
            c.addView(text("خرید: ${money(p.buyPrice)}  •  فروش: ${money(p.sellPrice)} تومان", 12f, muted))
            c.setOnClickListener { productDialog(p) }
            list.addView(c, LinearLayout.LayoutParams(-1, dp(92)).apply { bottomMargin = dp(10) })
        }
        if (store.products().isEmpty()) { val empty = text("هنوز عطری در انبار ثبت نشده.", 14f, muted); empty.gravity = Gravity.CENTER; list.addView(empty, LinearLayout.LayoutParams(-1, dp(120))) }
        content.addView(list)
        v.addView(scroll(content), LinearLayout.LayoutParams(-1, 0, 1f)); setContentView(v)
    }

    private fun productDialog(existing: Product?) {
        val d = Dialog(this); val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(20), dp(22), dp(20)); setBackgroundColor(Color.rgb(20,21,23)); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        box.addView(text(if (existing == null) "افزودن عطر" else "ویرایش عطر", 20f, white, true)); space(box, 10)
        val name = field("نام عطر", existing?.name ?: ""); val stock = field("موجودی", existing?.stock?.toString() ?: "0"); val buy = field("قیمت خرید", existing?.buyPrice?.toString() ?: "0"); val sell = field("قیمت فروش", existing?.sellPrice?.toString() ?: "0")
        listOf(name, stock, buy, sell).forEach { box.addView(it, LinearLayout.LayoutParams(-1, dp(56)).apply { bottomMargin = dp(8) }) }
        val save = button("ذخیره", {
            val n = name.text.toString().trim(); if (n.isEmpty()) { toast("نام عطر را وارد کن"); return@button }
            val list = store.products(); val p = existing ?: Product(System.currentTimeMillis(), n, 0, 0, 0)
            p.name = n; p.stock = max(0, stock.text.toString().toIntOrNull() ?: 0); p.buyPrice = buy.text.toString().toLongOrNull() ?: 0; p.sellPrice = sell.text.toString().toLongOrNull() ?: 0
            if (existing == null) list.add(p) else { val idx = list.indexOfFirst { it.id == p.id }; if (idx >= 0) list[idx] = p }
            store.saveProducts(list); d.dismiss(); showInventory()
        })
        box.addView(save, LinearLayout.LayoutParams(-1, dp(56)))
        d.setContentView(box); d.window?.setBackgroundDrawableResource(android.R.color.transparent); d.window?.setLayout(-1, -2); d.show(); d.window?.setLayout((resources.displayMetrics.widthPixels * .9).toInt(), -2)
    }

    private fun showInvoice(isSale: Boolean) {
        val v = base(if (isSale) "فاکتور فروش" else "فاکتور خرید")
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), 0, dp(18), dp(24)) }
        val name = field("نام و نام خانوادگی", ""); val phone = field("شماره تماس", ""); val date = field("تاریخ", today()); date.isFocusable = false; date.setOnClickListener { datePicker(date) }
        listOf(name, phone, date).forEach { content.addView(it, LinearLayout.LayoutParams(-1, dp(56)).apply { bottomMargin = dp(8) }) }
        val linesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val lines = mutableListOf<InvoiceLine>()
        fun renderLines() {
            linesBox.removeAllViews(); if (lines.isEmpty()) { linesBox.addView(text("هنوز کالایی به فاکتور اضافه نشده.", 13f, muted)) }
            lines.forEachIndexed { i, l ->
                val c = card(); val r = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
                r.addView(text(l.productName, 15f, white, true), LinearLayout.LayoutParams(0, dp(38), 1f)); r.addView(text("${l.qty} × ${money(l.unitPrice)}", 12f, cream));
                val del = TextView(this@MainActivity).apply { text = "×"; textSize = 24f; setTextColor(danger); gravity = Gravity.CENTER; setOnClickListener { lines.removeAt(i); renderLines() } }
                r.addView(del, LinearLayout.LayoutParams(dp(42), dp(42))); c.addView(r); c.addView(text("جمع: ${money(l.total)} تومان", 12f, muted)); linesBox.addView(c, LinearLayout.LayoutParams(-1, dp(82)).apply { bottomMargin = dp(8) })
            }
        }
        renderLines(); content.addView(linesBox)
        content.addView(button("＋ افزودن کالا", { lineDialog(isSale, lines, renderLines) }), LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(4); bottomMargin = dp(10) })
        val total = text("جمع کل: ۰ تومان", 18f, cream, true); content.addView(total, LinearLayout.LayoutParams(-1, dp(45)))
        content.addView(button("ثبت فاکتور", {
            if (name.text.toString().trim().isEmpty()) { toast("نام مشتری را وارد کن"); return@button }
            if (lines.isEmpty()) { toast("حداقل یک کالا اضافه کن"); return@button }
            val products = store.products()
            if (isSale && lines.any { l -> (products.find { it.id == l.productId }?.stock ?: 0) < l.qty }) { toast("موجودی یکی از کالاها کافی نیست"); return@button }
            lines.forEach { l ->
                val p = products.find { it.id == l.productId } ?: return@forEach
                p.stock += if (isSale) -l.qty else l.qty
                if (!isSale) p.buyPrice = l.unitPrice
                else p.sellPrice = l.unitPrice
            }
            store.saveProducts(products); store.addInvoice(isSale, name.text.toString().trim(), phone.text.toString().trim(), date.text.toString(), store.nextInvoiceId(), lines)
            toast("فاکتور با موفقیت ثبت شد"); showDashboard()
        }), LinearLayout.LayoutParams(-1, dp(60)).apply { topMargin = dp(6) })
        v.addView(scroll(content), LinearLayout.LayoutParams(-1, 0, 1f)); setContentView(v)
    }

    private fun lineDialog(isSale: Boolean, lines: MutableList<InvoiceLine>, refresh: () -> Unit) {
        val products = store.products(); if (products.isEmpty()) { toast("اول یک عطر به انبار اضافه کن"); return }
        val d = Dialog(this); val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(20), dp(22), dp(20)); setBackgroundColor(Color.rgb(20,21,23)); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        box.addView(text("افزودن کالا", 20f, white, true)); space(box, 10)
        val names = products.map { it.name }.toTypedArray(); val selector = AutoCompleteTextView(this).apply { hint = "انتخاب عطر"; setTextColor(white); setHintTextColor(muted); textSize = 15f; setPadding(dp(14), 0, dp(14), 0); setAdapter(ArrayAdapter(this@MainActivity, android.R.layout.simple_dropdown_item_1line, names)); threshold = 0 }
        box.addView(selector, LinearLayout.LayoutParams(-1, dp(56)).apply { bottomMargin = dp(8) })
        val qty = field("تعداد", "1"); val price = field(if (isSale) "قیمت فروش" else "قیمت خرید", "0"); box.addView(qty, LinearLayout.LayoutParams(-1, dp(56)).apply { bottomMargin = dp(8) }); box.addView(price, LinearLayout.LayoutParams(-1, dp(56)).apply { bottomMargin = dp(12) })
        selector.setOnItemClickListener { _, _, pos, _ -> price.setText((products[pos].let { if (isSale) it.sellPrice else it.buyPrice }).toString()) }
        box.addView(button("افزودن", {
            val p = products.find { it.name == selector.text.toString().trim() }; if (p == null) { toast("عطر را انتخاب کن"); return@button }
            val q = qty.text.toString().toIntOrNull() ?: 0; val pr = price.text.toString().toLongOrNull() ?: 0; if (q <= 0) { toast("تعداد معتبر نیست"); return@button }
            lines.add(InvoiceLine(p.id, p.name, q, pr)); d.dismiss(); refresh()
        }), LinearLayout.LayoutParams(-1, dp(56)))
        d.setContentView(box); d.window?.setBackgroundDrawableResource(android.R.color.transparent); d.show(); d.window?.setLayout((resources.displayMetrics.widthPixels * .9).toInt(), -2)
    }

    private fun field(hint: String, value: String): EditText = EditText(this).apply { setHint(hint); setText(value); setTextColor(white); setHintTextColor(muted); textSize = 15f; gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT; setPadding(dp(16), 0, dp(16), 0); background = android.graphics.drawable.GradientDrawable().apply { setColor(Color.rgb(23,25,27)); cornerRadius = dp(16).toFloat(); setStroke(dp(1), Color.rgb(45,44,42)) } }

    private fun datePicker(target: EditText) {
        val c = Calendar.getInstance(); DatePickerDialog(this, { _, y, m, d -> target.setText(String.format(Locale.US, "%04d/%02d/%02d", y, m + 1, d)) }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun today(): String = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date())
    private fun money(v: Long): String = String.format(Locale.US, "%,d", v)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun exportCsv() {
        val files = store.exportCsv(); var count = 0
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            files.forEach { f ->
                val values = android.content.ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME, f.name); put(MediaStore.Downloads.MIME_TYPE, "text/csv"); put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/AromaLedger") }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                if (uri != null) { contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }; count++ }
            }
            toast("$count فایل CSV در Download/AromaLedger ذخیره شد")
        } else toast("برای اندروید قدیمی، فایل‌ها داخل حافظه برنامه ذخیره هستند.")
    }
}
