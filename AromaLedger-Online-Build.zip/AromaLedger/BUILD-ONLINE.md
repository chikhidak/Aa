# ساخت آنلاین APK

1. یک Repository جدید در GitHub بساز.
2. محتویات این پوشه را داخل Repository آپلود کن.
3. از تب Actions، گزینه `Build AromaLedger APK` را باز کن.
4. روی `Run workflow` بزن.
5. بعد از اتمام Build، در بخش Artifacts فایل `AromaLedger-debug-apk` را دانلود کن.
